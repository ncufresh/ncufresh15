A Pen created at CodePen.io. You can find this one at http://codepen.io/anon/pen/BNOBLW.

 This is an example of how you can modify the CSS (or LESS in this case) of Video.js to create custom skins.

Forked from [Steve Heffernan](http://codepen.io/heff/)'s Pen [Video.js Custom Skin Example](http://codepen.io/heff/pen/wtrHL/).